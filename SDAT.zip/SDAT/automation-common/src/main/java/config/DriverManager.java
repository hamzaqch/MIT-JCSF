package config;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class DriverManager {

    private static final ThreadLocal<WebDriver> thread_driver_instance = new ThreadLocal<>();
    private static WebDriver driver;
    private static final ChromeOptions chromeOptions = new ChromeOptions();
    private static final FirefoxOptions ffOptions = new FirefoxOptions();
    private final Browser dbrowser = Browser.CHROME;

    private static final Thread CLOSE_THREAD = new Thread() {
        @Override
        public void run() {
            driver.quit();
        }
    };

    public WebDriver selectDriver(Browser dBrowser, Boolean headless ) {
        switch (dBrowser) {
            case CHROME:
                WebDriverManager.chromedriver().setup();
                chromeOptions.addArguments("--remote-allow-origins=*");
                chromeOptions.addArguments("window-size=1920,1080");
                chromeOptions.addArguments("-incognito");
                chromeOptions.addArguments("start-maximized");
                chromeOptions.addArguments("disable-infobars");
                chromeOptions.addArguments("--disable-extensions");
                chromeOptions.addArguments("--disable-gpu");
                chromeOptions.addArguments("--disable-dev-shm-usage");
                chromeOptions.addArguments("--no-sandbox");
                if (headless) {
                    setHeadLess(dBrowser);
                }
                driver = new ChromeDriver(chromeOptions);
                break;
            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                if (headless) {
                    setHeadLess(dBrowser);
                }
                driver = new FirefoxDriver(ffOptions);
                break;
            case EDGE:
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            default:
                break;
        }
        driver.manage().window().maximize();
        setWebDriver(driver);
        Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
        return driver;
    }

    /**
     * Method to get the current Driver
     * @return WebDriver
     */
    public WebDriver getDriver() {
        if (thread_driver_instance.get() != null) {
            return thread_driver_instance.get();
        } else {
            return getDefaultDriver();
        }
    }

    private static void setWebDriver(WebDriver driver) {
        thread_driver_instance.set(driver);
    }

    private static void setHeadLess(Browser dBrowser) {
        switch (dBrowser) {
            case CHROME:
                chromeOptions.addArguments("--headless");
                break;
            case FIREFOX:
                ffOptions.addArguments("--headless");
                break;
            default:
                break;
        }
    }

    public WebDriver getDefaultDriver() {
        if (thread_driver_instance.get() != null) {
            return thread_driver_instance.get();
        }
        driver = selectDriver(dbrowser, false);
        return getDriver();
    }

}
