package config;

public enum Browser {

    CHROME, FIREFOX, EDGE;

}
