package steps.common;

import pom.AbstractPage;
import io.cucumber.java.en.Then;

import java.io.IOException;

public class ScreenShotSteps extends AbstractPage {

	/**
	 * Step to take Screen shot
	 */
	@Then("^I take screenshot$")
	public void take_screenshot() throws IOException {
		screenShot_Obj.takeScreenShot();
	}

}
