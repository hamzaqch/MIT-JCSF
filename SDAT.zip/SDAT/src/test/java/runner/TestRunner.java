package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
                 dryRun = false,
                 monochrome = true,
                 plugin = {"pretty"
                		 ,"io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm"},
                 glue = {"steps"},
                 features = {"features"}
                )

public class TestRunner {

}
